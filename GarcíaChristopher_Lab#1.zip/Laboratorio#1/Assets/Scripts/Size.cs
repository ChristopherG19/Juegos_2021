﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Size : MonoBehaviour
{
    public float Velocidad = 10f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Q))
            transform.localScale += new Vector3(-Velocidad * Time.deltaTime,
                                                -Velocidad * Time.deltaTime,
                                                -Velocidad * Time.deltaTime);
        else if (Input.GetKey(KeyCode.E))
            transform.localScale += new Vector3(Velocidad * Time.deltaTime,
                                                Velocidad * Time.deltaTime,
                                                Velocidad * Time.deltaTime);
    }
}
