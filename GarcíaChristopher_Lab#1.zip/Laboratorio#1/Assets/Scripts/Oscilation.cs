﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Oscilation : MonoBehaviour
{

    public float Velocidad = 1f;
    private Vector3 origPos;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        transform.position = origPos + new Vector3(0, Mathf.Sin(Time.time)* Velocidad, 0);
          
    }
}
